const cursor = document.getElementById('cursor');
  const ring = document.getElementById('cursorRing');
  let mx = 0, my = 0, rx = 0, ry = 0;
  document.addEventListener('mousemove', e => {
    mx = e.clientX; my = e.clientY;
    cursor.style.left = mx - 5 + 'px';
    cursor.style.top = my - 5 + 'px';
  });
  function animateRing() {
    rx += (mx - rx - 18) * 0.12;
    ry += (my - ry - 18) * 0.12;
    ring.style.left = rx + 'px';
    ring.style.top = ry + 'px';
    requestAnimationFrame(animateRing);
  }
  animateRing();
  document.querySelectorAll('a, button').forEach(el => {
    el.addEventListener('mouseenter', () => { cursor.style.transform = 'scale(2.5)'; ring.style.opacity = '0'; });
    el.addEventListener('mouseleave', () => { cursor.style.transform = 'scale(1)'; ring.style.opacity = '1'; });
  });
  const reveals = document.querySelectorAll('.reveal');
  const observer = new IntersectionObserver(entries => {
    entries.forEach((entry, i) => {
      if (entry.isIntersecting) {
        setTimeout(() => entry.target.classList.add('visible'), i * 80);
        observer.unobserve(entry.target);
      }
    });
  }, { threshold: 0.1 });
  reveals.forEach(el => observer.observe(el));


// === Contact form (added): POST to backend /api/contact ===
(function () {
  var formEl = document.getElementById('contactForm');
  if (!formEl) return;

  var statusEl = document.getElementById('formStatus');

  var setStatus = function (msg, isError) {
    if (!statusEl) return;
    statusEl.textContent = msg;
    statusEl.style.color = isError ? '#EB3424' : 'rgba(240,239,254,0.75)';
  };

  formEl.addEventListener('submit', async function (evt) {
    evt.preventDefault();
    setStatus('Sending…', false);

    var payload = {
      name: document.getElementById('name').value.trim(),
      email: document.getElementById('email').value.trim(),
      phone: document.getElementById('phone').value.trim(),
      budget: document.getElementById('budget').value,
      message: document.getElementById('message').value.trim()
    };

    try {
      var resp = await fetch('/api/contact', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify(payload)
      });

      var data = await resp.json();
      if (!resp.ok) {
        setStatus(data.error || 'Something went wrong. Try again.', true);
        return;
      }

      setStatus('Message sent. We will contact you soon.', false);
      formEl.reset();
    } catch (err) {
      setStatus('Network error. Please try again.', true);
    }
  });
})();